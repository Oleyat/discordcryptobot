A simple cryptocurrency stat tracker.

If you wish to add it to your own discord server, invite it from here: https://top.gg/bot/723222469086806077.

<H2>COMMAND EXAMPLES</H2>

<img src="https://i.gyazo.com/7fa525855de39d28b5f64c6b41f7455f.png">


<img src="https://i.gyazo.com/5ea48de6317167c6fd36773b5f1328d4.png">


Feel free to use self-host the bot, but make sure to credit me.

Please donate with this link: https://ko-fi.com/zemcro
